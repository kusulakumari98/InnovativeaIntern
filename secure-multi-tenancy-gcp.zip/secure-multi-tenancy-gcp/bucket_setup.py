from google.cloud import storage

def create_secure_bucket(bucket_name, project_id, member_email):
    client = storage.Client(project=project_id)
    bucket = client.bucket(bucket_name)
    bucket.location = "us"
    bucket.iam_configuration.uniform_bucket_level_access_enabled = True
    bucket = client.create_bucket(bucket)

    policy = bucket.get_iam_policy()
    policy.bindings.append({
        "role": "roles/storage.objectViewer",
        "members": {f"user:{member_email}"}
    })
    bucket.set_iam_policy(policy)

    print(f"Bucket '{bucket_name}' created and access granted to {member_email}")
